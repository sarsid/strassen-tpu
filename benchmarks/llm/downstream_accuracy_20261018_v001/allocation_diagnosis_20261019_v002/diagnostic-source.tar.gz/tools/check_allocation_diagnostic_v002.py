"""Check no duplicate POST and no secret-bearing HTTP response logging."""
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'runtime'))
from allocate_accuracy_diagnostic_v002 import request_once, response_summary
from colab_cli.client import Assignment


class Tests(unittest.TestCase):
    def test_existing_assignment_blocks_post(self):
        client = Mock(); client.list_assignments.return_value = ['existing']
        with self.assertRaises(RuntimeError): request_once(client, 'old', 'fresh', Mock())
        client._post_assignment.assert_not_called()
        client._get_assignment.assert_not_called()

    def test_old_identity_is_recovered_without_new_post(self):
        client = Mock(); client.list_assignments.return_value = []
        value = Assignment(endpoint='owned', runtimeProxyInfo=dict(token='private-token', tokenExpiresInSeconds=60, url='https://example.invalid'))
        client._get_assignment.return_value = value
        self.assertIs(request_once(client, 'old', 'fresh', Mock()), value)
        client._get_assignment.assert_called_once()
        client._post_assignment.assert_not_called()

    def test_one_fresh_post_after_two_empty_checks(self):
        client = Mock(); client.list_assignments.return_value = []
        client._get_assignment.return_value = SimpleNamespace(token='private-token')
        request_once(client, 'old', 'fresh', Mock())
        self.assertEqual(client.list_assignments.call_count, 2)
        client._post_assignment.assert_called_once()
        self.assertEqual(client._post_assignment.call_args.args[0], 'fresh')

    def test_response_summary_excludes_secrets(self):
        summary = response_summary(SimpleNamespace(status_code=502, headers={'Content-Type':'text/html; charset=utf-8','Set-Cookie':'sensitive-cookie'}, content=b'Bad Gateway secret-token private-email@example.org'))
        self.assertEqual(summary['recognized_phrases'], ['bad gateway'])
        self.assertNotIn('secret-token', str(summary))
        self.assertNotIn('private-email', str(summary))
        self.assertNotIn('sensitive-cookie', str(summary))


if __name__ == '__main__': unittest.main(verbosity=2)
