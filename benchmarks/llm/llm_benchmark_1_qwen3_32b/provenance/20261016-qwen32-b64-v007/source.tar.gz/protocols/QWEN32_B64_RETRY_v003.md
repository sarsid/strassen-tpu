# Qwen3-32B B64 segmented capture retry

The user authorized repairing and running B64 on October 15. Scope: one v6e,
B64/S1024, Native/Tuned Native/Tuned Cubic/Tuned Strassen, BF16 output, DEFAULT
precision and the original parent JAX 0.7.2 / jaxlib 0.7.2 / libtpu 0.0.21.1.
Reuse the byte-identical saved B64 tuning profile from the first study; no
retuning or other workload is included. Preserve the failed v001/v002 attempts.

Both v002 qualification processes crashed with native SIGSEGV STACK OVERFLOW
while compiling the combined activation-capture graph. A related upstream JAX
attention compiler regression is documented in jax-ml/jax issue 40935. Its
identity with this crash is unconfirmed because our native trace is stripped.

The v003 diagnostic collector divides the same full-batch computation into four
compiled steps: native Q/K/V preparation, XLA causal attention, native output
projection/residual/MLP normalization, and native gate-up/SwiGLU. Cuts occur at
existing BF16 values. Materialized Q/K/V inputs prevent compiler fusion of their
producer graph into attention. Every step uses the entire B64/S1024 workload;
there is no microbatching, changed attention algorithm, sequence reduction,
software upgrade, or change to a measured kernel. Compilation boundaries may
still change finite-precision results, so their numerical effect is measured.

Capture staging remains outside timing and feeds the same restored input to all
four algorithms at each projection site. Record each compile, completed capture
part, input shape and input hash. Distinguish front-end lowering completion from
backend compilation completion to localize future failures.

Before TPU allocation, validate exact parent math at reduced CPU dimensions for
B1/B8/B32/B64, including nontrivial grouped-query attention and RoPE. Compare
captured sites and reconstructed Native output to the original collector/block.
Also lower the real B64 dimensions abstractly without allocating their arrays;
this checks shape tracing only, not TPU compilation or device-memory fit.

Full-size qualification loads real layer-0 weights, runs segmented capture and
reconstructs the Native block using its captured down-projection input and
residual. Require finite four-arm outputs and reconstruction relative L2 <= .01
against the unchanged compiled Native block. This is an additional capture
qualification threshold, not a substitute for the original predictive gates.
If qualification fails, do not begin performance confirmation.

After qualification, run unchanged projection/block confirmation, all 64
resident layers, four natural-text quality segments, and serialized cached-disk
offloaded prefill. Keep the original warmups/repeats, error metrics and gates.
Retain one fresh-process retry per failed stage, with all evidence preserved.
Save under results/v6e/qwen32_b64_retry_20261015_v003. Freeze and commit sources
before execution, archive every result/failure, update the live log, and release
the owned TPU afterward. Any further compiler workaround must use a new source
version and remain separately identified; do not silently upgrade the stack.
