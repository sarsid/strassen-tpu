"""Paired subset scoring helpers. No model allocation or execution on import.

The prepared input manifest and an independently admitted execution contract
are required by the study driver. These functions never choose test examples.
"""
import math
import re
import numpy as np

ARMS=('native','strassen')
STOPS=('Question:','</s>','<|im_end|>')


def strict_answer(text):
    match=re.search(r'#### (\-?[0-9\.\,]+)',text)
    if match is None:return None
    return re.sub(r'\.$','',match.group(1).replace(',','').replace('$','').strip().lower())


def terminated(ids,tokenizer,eos_ids,max_tokens):
    """Apply the same token/text stopping policy independently to each arm."""
    text=tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
    if ids and ids[-1] in eos_ids:
        # The EOS itself is excluded from answer extraction, as in a generation
        # API that terminates on EOS and decodes without that terminal token.
        return 'eos',tokenizer.decode(ids[:-1],skip_special_tokens=False,clean_up_tokenization_spaces=False)
    endings=[(text.find(stop),stop) for stop in STOPS if stop in text]
    if endings:
        at,stop=min(endings)
        return 'stop_string:'+stop,text[:at]
    if len(ids)>=max_tokens:return 'max_new_tokens',text
    return None,text


def packed(rows,batch=8,width=None):
    if not rows or len(rows)>batch:raise ValueError('Invalid fixed-batch row count')
    size=width or 128*math.ceil(max(len(x['token_ids']) for x in rows)/128)
    ids=np.zeros((batch,size),np.int32);lengths=np.ones(batch,np.int32)
    for i,row in enumerate(rows):
        n=len(row['token_ids'])
        if not 0<n<=size:raise ValueError('Truncation is not allowed')
        ids[i,:n]=row['token_ids'];lengths[i]=n
    positions=np.tile(np.arange(size,dtype=np.int32),(batch,1))
    return ids,positions,lengths


def log_probs(logits):
    """Stable FP32 log-softmax; aggregate target losses in float64."""
    x=np.asarray(logits,np.float32)
    if not np.all(np.isfinite(x)):raise ValueError('Nonfinite logits')
    z=x-x.max(axis=-1,keepdims=True)
    return z-np.log(np.exp(z).sum(axis=-1,keepdims=True,dtype=np.float32))


def mmlu_batch(engine,rows,batch=8,width=None):
    if any(len(x)!=1 for row in rows for x in row['continuations']):
        raise ValueError('This admitted subset requires one-token choices')
    ids,pos,lens=packed(rows,batch,width);engine.reset(batch,ids.shape[1])
    logits,_,_=engine.forward({a:ids for a in ARMS},{a:pos for a in ARMS},{a:lens for a in ARMS},
        last_indices={a:lens-1 for a in ARMS},label='mmlu',retain_cache=False)
    result={a:[] for a in ARMS}
    for arm in ARMS:
        probs=log_probs(logits[arm])
        for i,row in enumerate(rows):
            scores=[float(probs[i,suffix[0]]) for suffix in row['continuations']]
            result[arm].append(dict(prediction='ABCD'[int(np.argmax(scores))],choice_log_likelihoods=scores))
    return result


def ppl_batch(engine,rows,batch=8,head_chunk=128):
    import jax
    ids,pos,lens=packed(rows,batch,width=2048);engine.reset(batch,2048)
    hidden,_,_=engine.forward({a:ids for a in ARMS},{a:pos for a in ARMS},{a:lens for a in ARMS},
        label='ppl',return_hidden=True,retain_cache=False)
    result={a:[] for a in ARMS}
    for arm in ARMS:
        for i,row in enumerate(rows):
            targets=np.asarray(row['target_positions'],np.int32)
            if len(targets)!=row['scored_tokens'] or np.any(targets<1) or np.any(targets>=lens[i]):
                raise ValueError('Invalid target mask')
            total=np.float64(0)
            for first in range(0,len(targets),head_chunk):
                positions=targets[first:first+head_chunk]
                values=hidden[arm][i,positions-1]
                logits=np.asarray(jax.device_get(engine.head_logits(values)),np.float32)
                probs=log_probs(logits)
                total-=probs[np.arange(len(positions)),ids[i,positions]].sum(dtype=np.float64)
            result[arm].append(dict(nll_sum=float(total),scored_tokens=len(targets),window_index=row['window_index']))
    return result


def gsm_batch(engine,rows,tokenizer,eos_ids,emit,batch=8,max_tokens=1024,width=None,capacity=None):
    ids,pos,lens=packed(rows,batch,width)
    cap=capacity or 128*math.ceil((int(lens.max())+max_tokens)/128)
    if int(lens.max())+max_tokens>cap:raise ValueError('KV capacity too small')
    engine.reset(batch,cap)
    tokens={a:ids for a in ARMS};positions={a:pos for a in ARMS};lengths={a:lens.copy() for a in ARMS}
    last={a:lens-1 for a in ARMS}
    generated={a:[[] for _ in rows] for a in ARMS};finished={a:[None for _ in rows] for a in ARMS}
    for step in range(max_tokens):
        logits,seconds,compiled=engine.forward(tokens,positions,lengths,last_indices=last,
            label='gsm_prefill' if step==0 else 'gsm_decode')
        for arm in ARMS:
            chosen=np.argmax(logits[arm],axis=-1).astype(np.int32)
            next_ids=np.zeros((batch,1),np.int32);next_pos=np.zeros((batch,1),np.int32);next_lengths=np.ones(batch,np.int32)
            for i in range(len(rows)):
                if finished[arm][i] is not None:continue
                generated[arm][i].append(int(chosen[i]))
                reason,text=terminated(generated[arm][i],tokenizer,eos_ids,max_tokens)
                if reason is not None:
                    prediction=None if reason=='max_new_tokens' else strict_answer(text)
                    finished[arm][i]=dict(prediction=prediction,generated_text=text,
                        generated_token_ids=generated[arm][i].copy(),generated_tokens=len(generated[arm][i]),
                        stop_reason=reason,extracted_answer=strict_answer(text))
                else:
                    next_ids[i,0]=chosen[i];next_pos[i,0]=lengths[arm][i];next_lengths[i]=lengths[arm][i]+1
            tokens[arm]=next_ids;positions[arm]=next_pos;lengths[arm]=next_lengths;last[arm]=np.zeros(batch,np.int32)
        emit(dict(kind='gsm_generation_progress',step=step+1,max_new_tokens=max_tokens,
            examples=len(rows),completed_by_arm={a:sum(x is not None for x in finished[a]) for a in ARMS},
            paired_step_seconds=seconds,includes_compilation=compiled))
        if all(all(x is not None for x in finished[a]) for a in ARMS):break
    if any(x is None for a in ARMS for x in finished[a]):raise RuntimeError('Incomplete generation')
    return finished
