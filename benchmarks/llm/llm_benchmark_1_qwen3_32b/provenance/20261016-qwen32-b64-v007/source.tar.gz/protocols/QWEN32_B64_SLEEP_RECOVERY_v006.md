# B64 runtime-loss recovery

The authorized B64 restart v005 completed tuning in 1531 seconds and
qualification in 103 seconds. Five isolated projection confirmations were
preserved. The last successful snapshot was 2026-10-15 22:30:49 UTC; macOS
entered idle sleep at 22:30:50 UTC. On reconnection Colab no longer listed the
owned endpoint. The service supplied no termination reason. Sleep definitely
interrupted local monitoring/keep-alives; missed keep-alives are the likely
explanation for the lost allocation. No full-model timing/quality conclusion
is supported by the partial data. The absent runtime's local controller was
retired and its private session entry removed after fresh absence verification.

Continue the user's active B64-only restart authorization in a new run. Retain
measurement stage v004, worker v004, compiler versions, parent sources and all
timing/quality settings. Repeat tuning because the original final profile was
not downloaded; do not infer its contents from partial candidates.

Use controller v006 and poller v002. Each successful stage's final profile or
summary is included in subsequent snapshots, hash-checked, saved immutably and
committed locally. A confirmed absent endpoint is a lost runtime, not a
transient polling timeout: verify against a fresh allocation list, stop its
controller, preserve partial evidence and do not issue an unassignment for a
different runtime. Transient polling timeouts retain the validated reconnect
behavior. Test checkpoint integrity, failed-stage exclusion, timeout recovery,
and verified endpoint absence with local fault injection.

Launch starter v007 with --keep-waiting, wrapped in /usr/bin/caffeinate -i.
The assertion lasts only while that starter/controller is alive and prevents
automatic idle system sleep; it does not change display sleep settings or
override lid closure. The local laptop must remain open and connected.
The starter may keep retrying capacity failures indefinitely, with five-minute
backoff, and still stops for authentication or ambiguous allocation ownership.
No unrelated experiment is queued. Preserve all partial/failed runs, archive
new results and release the new owned TPU after completion.
