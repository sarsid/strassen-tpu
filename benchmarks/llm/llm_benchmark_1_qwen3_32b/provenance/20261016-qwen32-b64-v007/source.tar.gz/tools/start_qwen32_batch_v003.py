"""Explicit-start-only supervisor for the prepared B32/B64 memory-repair retry."""
import argparse
from datetime import datetime,timezone
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]


def records(path):
    rows=[]
    if path.exists():
        for line in path.read_text().splitlines():
            try: rows.append(json.loads(line))
            except ValueError: pass
    return rows


def main():
    p=argparse.ArgumentParser(); p.add_argument('--run',type=Path,required=True)
    p.add_argument('--start-authorized',action='store_true'); p.add_argument('--controller-python',required=True); p.add_argument('--await-existing',action='store_true'); a=p.parse_args()
    if not a.start_authorized: p.error('Prepared only: explicit user resumption is required before allocation')
    run=a.run.resolve()
    if not run.is_relative_to(ROOT/'runs'): raise ValueError('Run must belong to this repository')
    lock=(run/'starter.lock').open('ab'); fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    if (run/'control').exists(): raise RuntimeError('Controller already started; do not launch a duplicate')
    manifest=json.loads((run/'source-manifest.json').read_text())
    controller=ROOT/'tools/run_qwen32_batch_v002.py'
    if hashlib.sha256(controller.read_bytes()).hexdigest()!=manifest['files']['tools/run_qwen32_batch_v002.py']:
        raise RuntimeError('Controller differs from the validated frozen source')
    events=run/'allocation-events.jsonl'; last=None; endpoint=None
    def progress(title,detail,state='working'):
        subprocess.run(['python3',str(ROOT/'tools/record_progress_v001.py'),'--kind','activity','--state',state,'--title',title,'--detail',detail,'--evidence',str(events.relative_to(ROOT))],check=True,stdout=subprocess.DEVNULL)
    def owned():
        values=[r for r in records(events) if r.get('kind')=='allocation' and r.get('created') and r.get('session')==run.name]
        if len(values)>1: raise RuntimeError('Multiple allocation receipts require reconciliation')
        return values[0]['endpoint'] if values else None
    if a.await_existing:
        deadline=time.monotonic()+1300
        while time.monotonic()<deadline:
            endpoint=owned()
            if endpoint: break
            rows=records(events); last=rows[-1] if rows else {}
            if last.get('kind')=='allocation_error': break
            time.sleep(10)
        else: raise TimeoutError('Existing allocation request did not settle; no duplicate request made')
    for attempt in range(24):
        endpoint=owned()
        if endpoint: break
        if last and last.get('http_status') in (401,403):
            progress('Colab authentication needs attention','Allocation returned an authentication/access error. No measurements started.','blocked')
            return 1
        if attempt or a.await_existing:
            progress('Waiting to retry Colab allocation','No confirmed allocation. Retrying the same tracked request after a five-minute pause; no measurements started.')
            # A single relative sleep hides liveness and can extend across host
            # sleep. Anchor the pause to the provider failure's wall-clock time.
            failed_at=last.get('utc') if last else None
            try:
                retry_at=datetime.fromisoformat(failed_at).timestamp()+300
            except (ValueError,TypeError):
                retry_at=time.time()+300
            while time.time()<retry_at:
                remaining=max(0,int(retry_at-time.time()))
                progress('Colab allocation retry countdown',str(remaining)+' seconds until the next tracked request; no measurements started.')
                time.sleep(min(30,max(0,retry_at-time.time())))
        command=[a.controller_python,str(run/'allocation-tools/allocate_llm_diagnostic_v001.py'),'--session',run.name,'--journal-root',str(ROOT),'--events',str(events)]
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        with (run/f'provisioning-retry-v002-{stamp}-{attempt:02d}.log').open('x') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=1300)
        rows=records(events); last=rows[-1] if rows else {}
        if last.get('message','').startswith(('Existing assignment','Session already exists')):
            progress('Allocation reconciliation needs attention','Colab lists an allocation that has no confirmed owned receipt. No duplicate allocation or benchmark was started.','blocked')
            return 1
    endpoint=owned()
    if not endpoint:
        progress('Colab capacity wait exhausted','No confirmed allocation after the bounded retry window; all requests retained. No benchmark started.','blocked')
        return 1
    progress('v6e assigned; starting B32/B64 preflight','Confirmed owned allocation. Reusing saved profiles; preflight then confirmation, quality and prefill for B32 and B64.')
    command=[a.controller_python,str(controller),'--run',str(run),'--controller-python',a.controller_python,'--allocated-endpoint',endpoint]
    (run/'controller-launch.json').write_text(json.dumps(dict(command=command,utc=datetime.now(timezone.utc).isoformat(),source_sha256=manifest['source_sha256']),indent=2)+'\n')
    with (run/'controller.log').open('x') as log:
        return subprocess.call(command,stdout=log,stderr=subprocess.STDOUT)


if __name__=='__main__': raise SystemExit(main())
