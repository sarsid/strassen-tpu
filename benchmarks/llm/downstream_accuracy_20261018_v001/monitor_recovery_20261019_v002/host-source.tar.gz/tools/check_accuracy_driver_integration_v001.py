"""Execute the full scoring driver with fake model outputs, including resume.

Uses the frozen input manifests to test orchestration, not model quality. All
fake scores are confined to temporary directories and never published as results.
"""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
from transformers import AutoTokenizer
import accuracy_study_v001 as driver


class FakeEngine:
    def __init__(self,model,cache,emit):
        self.model=model;_,self.repo,self.revision=driver.MODELS[model];self.cache=cache
        (cache/'canonical').mkdir(parents=True,exist_ok=True)
        emit(dict(kind='engine_contract',model=self.repo,revision=self.revision,hardware=['FAKE DEVICE - NOT RESULTS']))
    def prepare(self):pass


class Tests(unittest.TestCase):
    def execute(self,model,output,cache,fail_gsm=False,forbid_earlier=False):
        data=driver.ROOT/'plans/llm_accuracy_20261018_v001'
        def mmlu(engine,rows,**kwargs):
            if forbid_earlier:raise AssertionError('Completed MMLU batch rerun')
            return {a:[dict(prediction=r['gold'],choice_log_likelihoods=[0.]*4) for r in rows] for a in driver.ARMS}
        def ppl(engine,rows,**kwargs):
            if forbid_earlier:raise AssertionError('Completed PPL batch rerun')
            return {a:[dict(nll_sum=2*r['scored_tokens'],scored_tokens=r['scored_tokens'],window_index=r['window_index']) for r in rows] for a in driver.ARMS}
        def gsm(engine,rows,*args,**kwargs):
            if fail_gsm:raise RuntimeError('Injected process failure before first GSM8K batch')
            return {a:[dict(prediction=r['gold'],generated_text='#### '+r['gold'],stop_reason='eos') for r in rows] for a in driver.ARMS}
        original_version=driver.md.version
        def version(name):
            try:return original_version(name)
            except driver.md.PackageNotFoundError:return '0.0.0'
        args=['study','--model',model,'--inputs',str(data/f'subset_{model}_v002'),'--pilot',str(data/f'pilot_{model}_v001.json'),'--output',str(output),'--cache',str(cache)]
        with patch.object(sys,'argv',args),patch.object(driver,'Engine',FakeEngine),patch.object(driver,'qualify',return_value={'status':'passed','scope':'SYNTHETIC TEST ONLY'}),patch.object(driver,'mmlu_batch',mmlu),patch.object(driver,'ppl_batch',ppl),patch.object(driver,'gsm_batch',gsm),patch.object(driver.md,'version',version),patch.object(driver.jax,'default_backend',return_value='tpu'),patch.object(driver.jax,'devices',return_value=[types.SimpleNamespace(device_kind='FAKE v6e')]),patch.object(AutoTokenizer,'from_pretrained',return_value=object()),contextlib.redirect_stdout(io.StringIO()):
            driver.main()

    def test_all_three_complete_driver_paths(self):
        with tempfile.TemporaryDirectory() as d:
            for model in driver.MODELS:
                out=Path(d)/model;self.execute(model,out,Path(d)/('weights-'+model))
                report=json.loads((out/'summary.json').read_text())
                self.assertEqual(set(report['tasks']),{'mmlu','gsm8k','ppl'})
                self.assertEqual(report['tasks']['mmlu']['n'],114)
                self.assertEqual(report['tasks']['gsm8k']['n'],32)
                self.assertEqual(report['tasks']['ppl']['scored_tokens'],16384)
                self.assertEqual(len(list((out/'batches').glob('*.json'))),23)

    def test_resume_uses_saved_pairs(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'output';cache=Path(d)/'weights'
            with self.assertRaisesRegex(RuntimeError,'Injected'):self.execute('qwen3_14b',out,cache,fail_gsm=True)
            self.assertEqual(len(list((out/'batches').glob('*.json'))),19)
            self.assertFalse((out/'summary.json').exists())
            self.execute('qwen3_14b',out,cache,forbid_earlier=True)
            self.assertTrue((out/'summary.json').exists())


if __name__=='__main__':unittest.main(verbosity=2)
