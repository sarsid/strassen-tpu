# B64 monitoring recovery

**Operator pause:** on October 15 the user requested no restart until returning
home. Local repair and validation may finish; TPU allocation and execution must
wait for explicit resumption. No new runtime was allocated for this recovery.

The current-stack v004 run compiled and executed Native and Cubic/Strassen
tuning candidates, but did not complete tuning. At 15:35 UTC on October 15,
one monitoring subprocess exceeded its 120-second timeout. That exception
escaped the observation loop and entered the controller's release handler.
The runtime was released with absence verified. This was a controller failure;
the last saved worker snapshot was still tuning. It provides no confirmed B64
LLM performance or predictive-quality result.

Controller v005 converts a subprocess timeout into a failed observation,
retains partial client output, records reconnection in the live journal and
retries without relaunching the worker or releasing its TPU. The reconnect
budget is 90 minutes continuously without a usable snapshot. A successful
snapshot resets that budget. The absolute 48-hour controller limit remains.
An isolated timeout must not trigger cleanup. A local fault-injection check
exercises an actual client timeout and the complete controller path through
timeout, recovery, verified result download and one final release.

Continue the user's authorized B64-only experiment in a new run directory.
Measurement stage v004, remote worker v004, the current-stack v004 protocol,
all parent sources and all timing/accuracy settings remain unchanged. Retune
from scratch; partial tuning samples are diagnostic evidence, not a frozen
profile and not pooled into confirmation. Save outputs under the existing
current-stack result root in the new run's own directory. Preserve the failed
run and recovered partial samples. No other batch or model is queued.
