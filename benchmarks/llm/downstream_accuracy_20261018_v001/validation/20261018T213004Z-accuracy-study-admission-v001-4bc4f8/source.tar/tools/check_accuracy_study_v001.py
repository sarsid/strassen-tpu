"""Admission/statistics checks; synthetic fixtures are not benchmark results."""
import json
from pathlib import Path
import tempfile
import types
import unittest
import numpy as np
from accuracy_study_v001 import qualify,save
from accuracy_analysis_v003 import analyze


class Fixture:
    repo='model';revision='revision'
    def __init__(self,delta=0):self.calls=0;self.delta=delta
    def reset(self,*args):pass
    def forward(self,*args,**kwargs):
        self.calls+=1
        v=np.ones((8,10))+(self.delta if self.calls==2 else 0)
        return {'native':v,'strassen':v},.01,False


class Tests(unittest.TestCase):
    def pilot(self):return dict(scope='train_generation_timing_pilot',model='model',revision='revision',token_ids=[list(range(64))]*8,example_ids=list(range(8)),inputs_sha256='train')
    def test_admission_passes_identical_cache_and_fails_drift(self):
        self.assertEqual(qualify(Fixture(),self.pilot(),lambda _:None)['status'],'passed')
        self.assertEqual(qualify(Fixture(.01),self.pilot(),lambda _:None)['status'],'failed')
        with self.assertRaises(ValueError):qualify(Fixture(float('nan')),self.pilot(),lambda _:None)
        pilot=self.pilot();pilot['scope']='test'
        with self.assertRaises(ValueError):qualify(Fixture(),pilot,lambda _:None)

    def test_artifacts_are_immutable(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'result.json';save(p,{'a':1});save(p,{'a':1})
            with self.assertRaises(ValueError):save(p,{'a':2})
            self.assertEqual(json.loads(p.read_text()),{'a':1})

    def test_budget_exhaustion_and_stratified_interval(self):
        specs=[dict(task='mmlu',example_id='m'+str(i),gold='A',subject='s'+str(i//2),input_sha256=str(i)) for i in range(114)]
        specs.append(dict(task='gsm8k',example_id='g',gold='42',subject=None,input_sha256='gsm'))
        manifest=dict(admission_status='passed',protocol_sha256='p',checkpoint_revision='r',execution_contract_sha256='e',model='fixture',examples=specs)
        with tempfile.TemporaryDirectory() as d:
            paths=[]
            for arm in ('native','strassen'):
                rows=[dict(s,arm=arm,protocol_sha256='p',checkpoint_revision='r',execution_contract_sha256='e',prediction='A') for s in specs[:-1]]
                rows.append(dict(specs[-1],arm=arm,protocol_sha256='p',checkpoint_revision='r',execution_contract_sha256='e',prediction=None,generated_text='#### 42',stop_reason='max_new_tokens'))
                path=Path(d)/arm;path.write_text(''.join(json.dumps(x)+'\n' for x in rows));paths.append(path)
            report=analyze(manifest,*paths)
            self.assertEqual(report['tasks']['gsm8k']['baseline_score'],0)
            self.assertEqual(report['tasks']['mmlu']['criterion'],'inconclusive')
            self.assertIn('Hoeffding',report['tasks']['mmlu']['confidence_method'])
            self.assertLess(report['tasks']['mmlu']['confidence_interval'][0],-25)


if __name__=='__main__':unittest.main(verbosity=2)
