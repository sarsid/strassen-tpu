# Qwen3-32B B32/B64 preparation-memory repair

Status: prepared for local validation; no TPU launch authorized until the user
returns to the office and explicitly requests resumption. This document extends
QWEN32_PARENT_BATCH_v001.md. The completed B1/B4/B8/B16 results and failed
B32/B64 attempts remain immutable. Save new results separately under
`results/v6e/qwen32_parent_batch_retry_20261015_v002`.

## Cause and bounded change

Both large batches reached confirmation after successful tuning. The eager
projection-input collector called the parent's attention prefix operation by
operation. B32 failed allocating an 8 GiB attention/softmax intermediate with
3.94 GiB free; B64 failed reserving a 16 GiB attention intermediate with
10.14 GiB free. The compiled Native full block had already run successfully
at both sizes during tuning. These failures therefore do not establish that
the compiled four-arm experiment cannot fit.

`tools/qwen32_batch_stage_v002.py` turns collection into a pure function and
compiles the entire parent attention-prefix and native SwiGLU preparation.
It returns only the six projection inputs and residual. It retains all parent
operations, attention implementation, BF16 casts and DEFAULT precision.
Captured inputs are staged on the host between isolated projection sites;
only the current site's input and required residual are restored. Transfers
are synchronized before warmup and excluded from projection timing. Inputs
are hashed for provenance. Capture executables and site outputs are released
between measurements so diagnostics do not retain unnecessary device arrays.

No timed kernel, model block, timing order, warmup count, repeat count,
quality formula, acceptance threshold or offloaded-prefill computation changes.
All four arms receive identical restored inputs for each isolated projection.
Whole-layer confirmation still propagates each arm's own activations at the
full requested batch size. There is no microbatching, reduced sequence length,
replacement attention kernel or alteration to the parent sources.

## Retry schedule

Only B32 then B64, both S1024, are registered. Reuse the byte-identical profiles
from successful v001 B32 tuning attempt 0 and B64 tuning attempt 1. SHA256 and
batch/sequence are verified before use. No tuning is repeated or selected on
confirmation results; the profiles originated on the earlier allocation.

Each batch runs fresh processes for:

1. `qualify`: compile and execute real-weight target-size capture, then one
   complete block for all four arms. Record compiler memory estimates and
   finite/error diagnostics. This is an untimed fit check, not a performance
   result or replacement for held-out quality checks.
2. `confirm`: six projections, block 0 and all 64 layers, with original counts.
3. `quality`: the original four natural-text segments and all four arms.
4. `prefill`: the original separately measured offloaded pipeline.

Retain at most one fresh-process retry per stage and preserve both attempts.
A failed stage prevents dependent stages for that batch, while the other
batch can continue. Retain failed large-batch memory results; do not silently
change model math to make a run fit. Export and locally commit each batch,
then archive the whole run and verify release of the owned TPU.

## Validation and launch boundary

`tools/check_qwen32_batch_v002.py` runs on CPU with reduced model dimensions
and batches 1, 8, 32 and 64. It executes the pinned parent attention, RoPE,
normalization and matmul functions, compares compiled capture with the original
eager collector, reconstructs the native block output, verifies host staging,
checks frozen-profile integrity, verifies unchanged timed/quality functions,
and rejects a starter invocation without explicit resumption. Numerical
regression uses relative L2 below 1% for BF16 capture/reconstruction; raw
observed differences are recorded. This local diagnostic tolerance does not
replace or relax any of the original model-quality gates.

These CPU checks cannot establish full-size TPU memory fit or speed. The
target-size `qualify` stage remains mandatory after the user authorizes launch.

The prepared run is `runs/20261015-qwen32-large-batch-v002`. Its frozen source
archive, manifest and local validation receipt must be verified before starting.
`tools/start_qwen32_batch_v003.py` requires `--start-authorized`, preserves the
existing bounded allocation retry mechanism, and launches only
`tools/run_qwen32_batch_v002.py`. Do not invoke it before the user's explicit
resumption. No automation or background allocator is started by preparation.
