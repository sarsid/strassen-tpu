"""Regression checks for the actual observer CLI and startup acknowledgement."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
from start_accuracy_study_v002 import observer_command,wait_ready


class Tests(unittest.TestCase):
    def test_actual_launched_command_parses(self):
        root=Path(__file__).resolve().parents[1]
        cmd=observer_command(root,'test-session','owned-endpoint')
        result=subprocess.run(cmd+['--validate-cli'],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout),dict(run_id='test-session',session='test-session',endpoint='owned-endpoint'))
        wrong=['--expect-endpoint' if x=='--endpoint' else x for x in cmd]
        rejected=subprocess.run(wrong+['--validate-cli'],capture_output=True,text=True)
        self.assertNotEqual(rejected.returncode,0)

    def test_readiness_requires_live_matching_process(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);path=root/'observer-ready-v002.json'
            path.write_text(json.dumps(dict(pid=7,endpoint='owned')))
            wait_ready(types.SimpleNamespace(pid=7,poll=lambda:None),root,'owned',timeout=.01)
            with self.assertRaises(RuntimeError):wait_ready(types.SimpleNamespace(pid=7,poll=lambda:2),root,'owned',timeout=.01)
            with self.assertRaises(RuntimeError):wait_ready(types.SimpleNamespace(pid=8,poll=lambda:None),root,'owned',timeout=.01)


if __name__=='__main__':unittest.main(verbosity=2)
