"""Large-batch retry controller: separate evidence, original timings, owned release."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True)
    p.add_argument('--controller-python',required=True)
    p.add_argument('--allocated-endpoint',required=True);a=p.parse_args()
    run=a.run.resolve();source=run/'source';out=run/'control';out.mkdir()
    root=Path(__file__).resolve().parents[1]
    controller=[a.controller_python,str(source/'runtime/colab_control_v003.py')]
    session=run.name[:90]
    def command(name,argv,timeout=240):
        with (out/(name+'.log')).open('x') as log:
            result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
        records=[]
        for line in (out/(name+'.log')).read_text().splitlines():
            try:records.append(json.loads(line))
            except ValueError:pass
        return result.returncode,records
    receipt=dict(started_utc=datetime.now(timezone.utc).isoformat(),session=session,status='verifying_allocation')
    endpoint=a.allocated_endpoint
    events=[json.loads(line) for line in (run/'allocation-events.jsonl').read_text().splitlines()]
    owned=[r for r in events if r.get('kind')=='allocation' and r.get('created')
           and r.get('session')==session and r.get('endpoint')==endpoint]
    if len(owned)!=1:
        raise RuntimeError('Require exactly one owned allocation receipt for this run')
    code,records=command('verify-allocation',controller+['list'])
    active=[item for row in records if row.get('kind')=='allocations'
            for item in row['assignments'] if item.get('endpoint')==endpoint
            and item.get('name')==session and item.get('accelerator')=='V6E1']
    if code or len(active)!=1:
        raise RuntimeError('Owned v6e allocation is not live in the saved session')
    common=['--session',session,'--expect-endpoint',endpoint]
    receipt.update(endpoint=endpoint,status='running')
    (run/'allocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    plan=json.loads((source/'configs/qwen32_b64_current_stack_v004.json').read_text())
    previous=None
    downloaded=set()
    try:
        code,_=command('bootstrap',controller+['exec-file',*common,'--file',str(source/'runtime/bootstrap_parent_replication_v001.py'),'--timeout','60'])
        if code:raise RuntimeError('Remote bootstrap failed')
        remote='/content/Strassen_MM_Focus/'+run.name+'-source.tar'
        code,_=command('upload',controller+['upload',*common,'--local',str(run/'source.tar'),'--remote',remote])
        if code:raise RuntimeError('Source upload failed')
        code,_=command('launch',controller+['exec-file',*common,'--file',str(source/'runtime/qwen32_batch_remote_v004.py'),'--timeout','90',
            '--script-arg=--archive','--script-arg='+remote,'--script-arg=--sha256','--script-arg='+hashlib.sha256((run/'source.tar').read_bytes()).hexdigest(),
            '--script-arg=--run-id','--script-arg='+run.name])
        # Launch response can be lost. Poll before deciding whether work exists.
        deadline=time.monotonic()+172800
        failures=0
        for number in range(5760):
            if time.monotonic()>deadline:raise TimeoutError('Parent-only reproduction exceeded 48 hours')
            code,records=command('poll-'+str(number).zfill(3),controller+['exec-file',*common,'--file',str(source/'runtime/poll_qwen32_batch_v001.py'),'--timeout','60',
                '--script-arg=--run-id','--script-arg='+run.name],120)
            snapshot=None
            for record in records:
                if record.get('kind')=='remote_stream':
                    for line in record.get('text','').splitlines():
                        try:
                            value=json.loads(line)
                            if value.get('kind')=='qwen32_batch_snapshot':snapshot=value
                        except ValueError:pass
            if snapshot is None:
                failures+=1
                if failures>=180:raise RuntimeError('Ninety minutes of unavailable remote snapshots')
            else:
                failures=0
                (run/'latest.json').write_text(json.dumps(snapshot,indent=2)+'\n')
                state=snapshot.get('status.json',{})
                last={}
                for tail in snapshot.get('tails',{}).values():
                    for line in tail.splitlines():
                        try:
                            row=json.loads(line)
                            if isinstance(row,dict) and row.get('kind'):last=row
                        except ValueError:pass
                current=(state,last)
                if current!=previous:
                    previous=current
                    detail='Stage '+state.get('active',state.get('status','starting'))+'; '+str(len(state.get('batches',[])))+'/'+str(len(plan['batches']))+' batches archived. '+str({k:last[k] for k in ('kind','arm','site','tile','layer','segment','scored_positions','candidate_mib') if k in last})
                    subprocess.run(['python3',str(root/'tools/record_progress_v001.py'),'--kind','activity','--id','current','--state','working',
                        '--title','Qwen3-32B large-batch retry','--detail',detail,'--evidence',str((run/'latest.json').relative_to(root))],stdout=subprocess.DEVNULL,check=False)
                for ready_batch in state.get('batch_archives',[]):
                    batch=ready_batch['batch']
                    if batch in downloaded:continue
                    dest=root/plan['result_root']/run.name/('b'+str(batch))
                    dest.mkdir(parents=True,exist_ok=True)
                    package=dest/'results.tar.gz'
                    code,_=command('download-b'+str(batch),controller+['download',*common,'--remote',ready_batch['path'],'--local',str(package)],300)
                    if code or hashlib.sha256(package.read_bytes()).hexdigest()!=ready_batch['sha256']:raise RuntimeError('Unverified batch export')
                    with tarfile.open(package) as t:t.extractall(dest/'artifacts',filter='data')
                    (dest/'receipt.json').write_text(json.dumps(ready_batch,indent=2)+'\n')
                    relative=str(dest.relative_to(root))
                    subprocess.run(['git','add','--',relative],cwd=root,check=True)
                    subprocess.run(['git','commit','--only','-m','Archive Qwen3-32B B'+str(batch)+' current-stack B64 results results','--',relative],cwd=root,check=True)
                    downloaded.add(batch)
                if 'archive-ready.json' in snapshot:
                    ready=snapshot['archive-ready.json']
                    for attempt in range(3):
                        package=run/('remote-results-'+str(attempt)+'.tar.gz')
                        code,_=command('download-'+str(attempt),controller+['download',*common,'--remote',ready['path'],'--local',str(package)],300)
                        if not code and hashlib.sha256(package.read_bytes()).hexdigest()==ready['sha256']:break
                    else:raise RuntimeError('Result download not verified')
                    with tarfile.open(package) as t:t.extractall(run/'remote',filter='data')
                    receipt.update(status=state.get('status'),remote_summary=state,result_sha256=ready['sha256'])
                    break
            time.sleep(30)
        else:raise TimeoutError('Poll budget exhausted')
    except BaseException as error:
        receipt.update(status='controller_failed',error_type=type(error).__name__,error=str(error))
    finally:
        code,_=command('release',[a.controller_python,str(source/'runtime/release_allocation_v002.py'),*common])
        receipt.update(release_exit_code=code,finished_utc=datetime.now(timezone.utc).isoformat())
        (run/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n')
        print(json.dumps(receipt),flush=True)
    relative=str(run.relative_to(root))
    subprocess.run(['python3',str(root/'tools/record_progress_v001.py'),'--kind','activity','--state','complete' if receipt.get('release_exit_code')==0 else 'blocked','--title','Qwen32 batch worker finished','--detail','Status '+str(receipt['status'])+'; release exit code '+str(receipt.get('release_exit_code'))+'; results preserved in '+relative,'--evidence',relative+'/completion.json'],check=False)
    subprocess.run(['git','add','--',relative,'status/work_progress_v001.jsonl'],cwd=root,check=True)
    subprocess.run(['git','commit','--only','-m','Archive Qwen32 batch study completion and release','--',relative,'status/work_progress_v001.jsonl'],cwd=root,check=True)
    return 0 if receipt['status'] in ('completed','completed_with_failures') and receipt['release_exit_code']==0 else 1

if __name__=='__main__':raise SystemExit(main())
