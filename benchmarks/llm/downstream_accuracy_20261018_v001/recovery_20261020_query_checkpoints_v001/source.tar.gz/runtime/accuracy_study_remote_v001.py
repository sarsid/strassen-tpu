"""Run only the registered three-model downstream subset, retaining TPU on errors."""
import argparse
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import threading
import time

BASE=Path('/content/Strassen_MM_Focus')
MODELS=('qwen3_14b','qwen3_32b','gemma4_31b')


def save(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def archive(root,path):
    if not path.exists():
        temp=path.with_suffix('.partial')
        with tarfile.open(temp,'w:gz') as out:out.add(root,arcname=root.name)
        temp.rename(path)
    value=dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    save(path.with_suffix('.ready.json'),value);return value


def worker(run):
    source=run/'source';artifacts=run/'artifacts';artifacts.mkdir(exist_ok=True)
    sys.path.insert(0,str(source/'runtime'))
    from parent_exact_remote_v001 import execute
    lock=(BASE/'active.lock').open('ab');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    private=BASE/'.runtime_private'/run.name;private.mkdir(parents=True,exist_ok=True)
    env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','HF_TOKEN','HUGGING_FACE_HUB_TOKEN','LIBTPU_INIT_ARGS','XLA_FLAGS','JAX_PLATFORMS') and not k.startswith(('PIP_','QWEN3_'))}
    env.update(PYTHONUNBUFFERED='1',PYTHONNOUSERSITE='1',JAX_PLATFORMS='tpu',HF_HOME=str(private/'huggingface'),HF_HUB_DISABLE_IMPLICIT_TOKEN='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='1',STRASSEN_SOURCE_SHA256=json.loads((run/'launch.json').read_text())['source_sha256'])
    state=dict(status='running',scope='three-model paired downstream subsets',started_utc=datetime.now(timezone.utc).isoformat(),completed_models=[],test_evaluations_completed=0,test_evaluations_total=9,release_attempted=False)
    stop=threading.Event()
    def stage(name,**extra):state.update(stage=name,updated_utc=datetime.now(timezone.utc).isoformat(),**extra);save(run/'status.json',state)
    def observe():
        selected=None;offset=0;context={}
        while not stop.wait(2):
            model=state.get('model');paths=sorted((artifacts/model).glob('events-*.jsonl')) if model else []
            if not paths:continue
            path=paths[-1]
            if selected!=path:selected=path;offset=0;context={'model':model,'completed_tasks':[]}
            try:
                with path.open() as f:
                    f.seek(offset)
                    while True:
                        old=f.tell();line=f.readline()
                        if not line or not line.endswith('\n'):f.seek(old);break
                        row=json.loads(line);context['latest_event']=row
                        if row['kind']=='task_batch_started':context.update({k:row[k] for k in ('task','batch','batches','completed_examples','total_examples')})
                        if row['kind']=='task_batch_complete':context.update(completed_examples=row['completed_examples'])
                        if row['kind']=='task_complete' and row['task'] not in context['completed_tasks']:context['completed_tasks'].append(row['task'])
                    offset=f.tell()
                save(run/'progress.json',dict(context,observed_utc=datetime.now(timezone.utc).isoformat()))
            except (OSError,ValueError):pass
    thread=threading.Thread(target=observe,daemon=True);thread.start()
    try:
        stage('installing_environment');python=private/'environment/bin/python'
        if not python.exists():
            code=execute([sys.executable,'-m','venv','--without-pip',str(python.parent.parent)],artifacts/'venv.log',env,120,source)
            if code:raise RuntimeError('Could not create environment')
        pins=['jax==0.11.2','jaxlib==0.11.2','libtpu==0.0.48','numpy==2.2.6','scipy==1.15.3','transformers==5.5.0','tokenizers==0.22.2','safetensors==0.8.0','requests==2.34.2','huggingface-hub==1.33.0']
        pip=[sys.executable,'-m','pip','--isolated','--python',str(python)]
        code=execute(pip+['install','--disable-pip-version-check','--only-binary=:all:','--report',str(artifacts/'installation.json'),*pins],artifacts/'install.log',env,900,source)
        if code:raise RuntimeError('Isolated environment setup failed')
        execute(pip+['freeze','--all'],artifacts/'freeze.txt',env,60,source)
        for model in MODELS:
            cache=private/('weights-'+model)
            if shutil.disk_usage(BASE).free<135*1024**3:raise RuntimeError('Insufficient private checkpoint disk capacity')
            output=artifacts/model
            cmd=[str(python),str(source/'tools/accuracy_study_v001.py'),'--model',model,
                '--inputs',str(source/f'plans/llm_accuracy_20261018_v001/subset_{model}_v002'),
                '--pilot',str(source/f'plans/llm_accuracy_20261018_v001/pilot_{model}_v001.json'),
                '--output',str(output),'--cache',str(cache)]
            save(artifacts/(model+'-command.json'),dict(command=cmd,source_sha256=env['STRASSEN_SOURCE_SHA256']))
            for attempt in range(2):
                stage('evaluating',model=model,attempt=attempt)
                code=execute(cmd,artifacts/f'{model}-attempt-{attempt}.log',env,24*3600,source)
                if code==0 and (output/'summary.json').exists():break
                stage('retrying_from_completed_batches',model=model,attempt=attempt,returncode=code)
            else:raise RuntimeError('Model failed after bounded restart; TPU retained for diagnosis')
            ready=archive(output,run/(model+'.tar.gz'));state['completed_models'].append(model)
            state['test_evaluations_completed']=3*len(state['completed_models']);stage('model_archived',model=model,model_archive=ready)
            # Only this disposable run/model weight cache is removed. Exact
            # checkpoint/canonical hashes remain in the public model archive.
            if cache.exists() and cache.parent==private:shutil.rmtree(cache)
        stage('complete',status='completed')
    except BaseException as error:
        state.update(status='failed',error_type=type(error).__name__)
        if type(error) is RuntimeError:state['error']=str(error)
    finally:
        stop.set();thread.join(timeout=5)
        state['finished_utc']=datetime.now(timezone.utc).isoformat();save(run/'status.json',state)
        ready=archive(artifacts,run/'all-artifacts.tar.gz');save(run/'archive-ready.json',ready);lock.close()


def main():
    p=argparse.ArgumentParser();p.add_argument('--archive',type=Path);p.add_argument('--sha256');p.add_argument('--run-id');p.add_argument('--worker',type=Path);a=p.parse_args()
    if a.worker:return worker(a.worker)
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',a.run_id or ''):raise ValueError('Invalid run ID')
    if not a.archive.resolve().is_relative_to(BASE) or hashlib.sha256(a.archive.read_bytes()).hexdigest()!=a.sha256:raise ValueError('Archive mismatch')
    run=BASE/'runs'/a.run_id;run.mkdir(parents=True,exist_ok=False);source=run/'source';source.mkdir()
    with tarfile.open(a.archive) as handle:handle.extractall(source,filter='data')
    command=[sys.executable,str(source/'runtime/accuracy_study_remote_v001.py'),'--worker',str(run)]
    save(run/'launch.json',dict(source_sha256=a.sha256,command=command,models=MODELS))
    with (run/'worker.log').open('x') as log:
        child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps(dict(kind='accuracy_study_launched',run=str(run),pid=child.pid,models=MODELS)),flush=True)


if __name__=='__main__':main()
