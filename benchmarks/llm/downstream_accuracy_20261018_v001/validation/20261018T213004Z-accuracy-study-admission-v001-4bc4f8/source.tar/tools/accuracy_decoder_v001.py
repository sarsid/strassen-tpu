"""Shared non-MM decoder semantics for the accuracy pilot, with explicit KV state.

Admission component: a complete checkpoint runner must still qualify this before
benchmark scoring. All algorithms call the same normalization/attention/activation
code. Only the supplied projection callable differs.
"""
import math
from pathlib import Path
import sys
import jax
import jax.numpy as jnp
from accuracy_mm_v001 import rounded,qwen_rms,qwen_mlp,gemma_mlp

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))


def native_projection(x,w):
    return rounded(jnp.matmul(x,w,precision=jax.lax.Precision.DEFAULT,preferred_element_type=jnp.float32))


def rotate(x,cos,sin):
    y=jnp.concatenate((-x[...,x.shape[-1]//2:],x[...,:x.shape[-1]//2]),axis=-1)
    return rounded(rounded(x.astype(jnp.float32)*cos[:,:,None].astype(jnp.float32)).astype(jnp.float32)
                   +rounded(y.astype(jnp.float32)*sin[:,:,None].astype(jnp.float32)).astype(jnp.float32))


def cached_attention(q,k,v,positions,lengths,scale,window=None,chunk=128):
    b,t,heads,d=q.shape;kv=k.shape[2];groups=heads//kv;length=k.shape[1]
    pad=(-t)%chunk
    qs=jnp.pad(q,((0,0),(0,pad),(0,0),(0,0))).reshape(b,-1,chunk,heads,d).swapaxes(0,1)
    ps=jnp.pad(positions,((0,0),(0,pad))).reshape(b,-1,chunk).swapaxes(0,1)
    key_positions=jnp.arange(length)
    def one(args):
        query,pos=args;query=query.reshape(b,chunk,kv,groups,d)
        scores=rounded(jnp.einsum('btkgh,bskh->bkgts',query,k,precision=jax.lax.Precision.DEFAULT,preferred_element_type=jnp.float32))
        scores=rounded(scores.astype(jnp.float32)*scale)
        allowed=(key_positions[None,None,:]<=pos[:,:,None])&(key_positions[None,None,:]<lengths[:,None,None])
        if window is not None:allowed &= key_positions[None,None,:]>pos[:,:,None]-window
        scores=jnp.where(allowed[:,None,None],scores,jnp.finfo(jnp.bfloat16).min)
        probs=rounded(jax.nn.softmax(scores.astype(jnp.float32),axis=-1))
        out=rounded(jnp.einsum('bkgts,bskh->btkgh',probs,v,precision=jax.lax.Precision.DEFAULT,preferred_element_type=jnp.float32))
        return out.reshape(b,chunk,heads,d)
    outputs=jax.lax.map(one,(qs,ps)).swapaxes(0,1).reshape(b,t+pad,heads,d)
    return outputs[:,:t]


def geometry(config,index):
    if config['model_type']=='qwen3':
        return dict(head_dim=config['head_dim'],query_heads=config['num_attention_heads'],
                    kv_heads=config['num_key_value_heads'],shared_raw_kv=False,sliding_window=None)
    from strassen_mm.gemma4_contract_v001 import layer_geometry
    return layer_geometry(config,index)


def make_layer(config,index,project=native_projection):
    qwen=config['model_type']=='qwen3';g=geometry(config,index)
    d=g['head_dim'];heads=g['query_heads'];kv=g['kv_heads'];eps=config['rms_norm_eps']
    if not qwen:
        from strassen_mm import model_gemma4_v001 as gemma
    def run(x,p,cache_k,cache_v,positions,lengths):
        b,t,h=x.shape
        if qwen:
            value=qwen_rms(x,p['norm1'],eps)
            inverse=1/(config['rope_theta']**(jnp.arange(0,d,2,dtype=jnp.float32)/d))
            phase=positions.astype(jnp.float32)[...,None]*inverse
            phase=jnp.concatenate((phase,phase),axis=-1)
            cos,sin=rounded(jnp.cos(phase)),rounded(jnp.sin(phase))
        else:
            value=gemma.rms(x,p['norm1'],eps)
            cos,sin=gemma.rotary_tables(config,index,positions)
        q=project(value,p['q']).reshape(b,t,heads,d)
        raw=project(value,p['k']).reshape(b,t,kv,d)
        v=raw if g['shared_raw_kv'] else project(value,p['v']).reshape(b,t,kv,d)
        if qwen:
            q=rotate(qwen_rms(q,p['qnorm'],eps),cos,sin)
            k=rotate(qwen_rms(raw,p['knorm'],eps),cos,sin)
        else:
            q=gemma.apply_rotary(gemma.rms(q,p['qnorm'],eps),cos,sin)
            k=gemma.apply_rotary(gemma.rms(raw,p['knorm'],eps),cos,sin)
            v=gemma.rms(v,None,eps)
        rows=jnp.arange(b)[:,None]
        cache_k=cache_k.at[rows,positions].set(k)
        cache_v=cache_v.at[rows,positions].set(v)
        attended=cached_attention(q,cache_k,cache_v,positions,lengths,1/math.sqrt(d) if qwen else 1.,g['sliding_window'])
        y=project(attended.reshape(b,t,heads*d),p['o'])
        if not qwen:y=gemma.rms(y,p['norm2'],eps)
        residual=rounded(x.astype(jnp.float32)+y.astype(jnp.float32))
        if qwen:
            value=qwen_rms(residual,p['norm2'],eps)
            value=qwen_mlp(value,p,project)
            out=rounded(residual.astype(jnp.float32)+value.astype(jnp.float32))
        else:
            value=gemma.rms(residual,p['norm3'],eps)
            value=gemma.rms(gemma_mlp(value,p,project),p['norm4'],eps)
            out=rounded(residual.astype(jnp.float32)+value.astype(jnp.float32))
            out=rounded(out.astype(jnp.float32)*p['layer_scalar'].astype(jnp.float32))
        return out,cache_k,cache_v
    return run
