"""Ownership guards for allocation retry; never call a provider API."""
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
from start_accuracy_study_v001 import owned,records


class Tests(unittest.TestCase):
    def test_only_unambiguous_owned_runtime_is_adopted(self):
        self.assertIsNone(owned([],'study'))
        self.assertEqual(owned([dict(name='study',endpoint='owned')],'study'),'owned')
        for values in [[dict(name='other',endpoint='other')],[dict(name='study',endpoint='owned'),dict(name='other',endpoint='other')]]:
            with self.assertRaises(RuntimeError):owned(values,'study')

    def test_non_json_lines_do_not_hide_result(self):
        self.assertEqual(records('notice\n{"kind":"allocation_error","http_status":502}\n'),[dict(kind='allocation_error',http_status=502)])


if __name__=='__main__':unittest.main(verbosity=2)
