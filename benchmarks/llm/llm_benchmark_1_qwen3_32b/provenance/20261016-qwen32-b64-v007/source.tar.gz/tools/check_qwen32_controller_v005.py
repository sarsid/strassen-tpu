"""Exercise timeout recovery through the controller without a TPU or network."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
from unittest.mock import patch

import run_qwen32_batch_v005 as controller


def main():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); logs=root/'logs'; logs.mkdir()
        code,rows=controller.control_command(logs,'real-timeout',
            [sys.executable,'-c',"import time; print('{\"kind\":\"before_timeout\"}',flush=True); time.sleep(2)"],.3)
        assert code==124
        assert any(r.get('kind')=='control_command_timeout' for r in rows)
        assert any(r.get('kind')=='before_timeout' for r in rows)
        code,rows=controller.control_command(logs,'after-timeout',
            [sys.executable,'-c',"print('{\"kind\":\"recovered\"}')"],2)
        assert code==0 and rows==[dict(kind='recovered')]

        run=root/'runs'/'simulated-b64';run.mkdir(parents=True)
        source=run/'source';(source/'configs').mkdir(parents=True)
        (source/'configs/qwen32_b64_current_stack_v004.json').write_text(json.dumps(
            dict(batches=[64],result_root='results/simulated')))
        (run/'source.tar').write_bytes(b'fake-source')
        endpoint='owned-test-endpoint'
        (run/'allocation-events.jsonl').write_text(json.dumps(dict(kind='allocation',
            created=True,session=run.name,endpoint=endpoint))+'\n')
        result_file=root/'result.json';result_file.write_text('{"status":"completed"}\n')
        package=root/'export.tar.gz'
        with tarfile.open(package,'w:gz') as t:t.add(result_file,arcname='test/artifacts/summary.json')
        ready=dict(path='/remote/results.tar.gz',sha256=hashlib.sha256(package.read_bytes()).hexdigest())
        calls=[];polls=0

        def fake_run(argv,**kw):
            nonlocal polls
            argv=[str(x) for x in argv];calls.append(argv)
            def emit(value):kw['stdout'].write(json.dumps(value)+'\n')
            if argv[1].endswith('release_allocation_v002.py'):
                assert polls==2, 'Runtime released after the first missing snapshot'
                assert (run/'remote/test/artifacts/summary.json').exists(), 'Release preceded verified export'
                emit(dict(kind='allocation_released',verified_absent=True))
            elif argv[1].endswith('colab_control_v003.py'):
                op=argv[2]
                if op=='list':emit(dict(kind='allocations',assignments=[dict(endpoint=endpoint,name=run.name,accelerator='V6E1')]))
                elif op=='download':Path(argv[argv.index('--local')+1]).write_bytes(package.read_bytes())
                elif op=='exec-file' and argv[argv.index('--file')+1].endswith('poll_qwen32_batch_v001.py'):
                    polls+=1
                    if polls==1:raise subprocess.TimeoutExpired(argv,120)
                    snapshot={'kind':'qwen32_batch_snapshot','status.json':dict(status='completed',batches=[dict(batch=64,status='completed')],batch_archives=[]),'archive-ready.json':ready,'tails':{}}
                    emit(dict(kind='remote_stream',text=json.dumps(snapshot)))
            return subprocess.CompletedProcess(argv,0)

        args=['run_qwen32_batch_v005.py','--run',str(run),'--controller-python',sys.executable,'--allocated-endpoint',endpoint]
        with patch.object(controller,'__file__',str(root/'tools/run_qwen32_batch_v005.py')), \
             patch.object(controller.subprocess,'run',side_effect=fake_run), \
             patch.object(controller.time,'sleep'),patch.object(sys,'argv',args):
            assert controller.main()==0
        completion=json.loads((run/'completion.json').read_text())
        assert completion['status']=='completed' and completion['release_exit_code']==0
        assert 'control_command_timeout' in (run/'control/poll-000.log').read_text()
        assert len([c for c in calls if c[1].endswith('release_allocation_v002.py')])==1
        assert len([c for c in calls if 'exec-file' in c and any('qwen32_batch_remote_v004.py' in v for v in c)])==1
        assert not any('allocate' in ' '.join(c) for c in calls)
    print(json.dumps(dict(status='passed',actual_subprocess_timeout='recovered',
        controller_poll_timeout='retried_without_release_or_relaunch',
        verified_archive_before_release=True,scope='local orchestration regression; no TPU/network')))


if __name__=='__main__':main()
