# Reuse the completed B64 tuning profile

The user correctly requested avoiding another tuning pass. The earlier
assessment that the completed profile was unavailable overlooked two complete
`frozen_profile` events in the locally preserved qualification/confirmation
logs. Restoring their profile JSON with the original serializer reproduces the
original file SHA-256 exactly:
`0459c624337428adfbef2e9bd8adaaa3a232c4df3e20c10cd4f25b9867fdc9f9`.
Both independent log copies agree. This is the actual completed selected
profile, not a reconstruction from partial candidate minima.

This supersedes the repeat-tuning instruction in the v006 recovery protocol.
Use configs/qwen32_b64_recovered_profile_v007.json with its pinned hash.
The originating tuning completed in run 20261015-qwen32-b64-v005 on v6e with
JAX/jaxlib 0.11.2 and libtpu 0.0.48. Use the same architecture/compiler stack
and all four original arms. Controller v007, starter v008 and worker v005
skip tuning, verify the profile hash, then run qualify, confirm, quality and
prefill. Measurement stage v004 and all parent sources, timing repetitions,
corpora and error gates remain unchanged. Recompile/qualify on the replacement
runtime before collecting fresh performance evidence; never pool partial
timing samples from the lost runtime into the new confirmation.

The superseded v006 allocation request failed with HTTP 502 before allocation
or worker launch. Preserve that request; stop its paused starter and use a
new run identity. Continue the user's authorized capacity wait. Wrap the new
starter in caffeinate -i, retain tested stage checkpoints and timeout recovery,
commit results and release the owned TPU afterward. Expected work after
allocation is about 60–90 minutes, excluding provider/retry delays.
