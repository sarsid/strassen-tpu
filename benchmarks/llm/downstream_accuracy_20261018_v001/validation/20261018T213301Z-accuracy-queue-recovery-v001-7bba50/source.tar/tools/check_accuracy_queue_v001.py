"""Offline queue/retry/archive validation; no allocation or model execution."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime'))
import accuracy_study_remote_v001 as worker


class Tests(unittest.TestCase):
    def run_queue(self,base,fail):
        run=base/'runs'/'fixture';(run/'source/runtime').mkdir(parents=True)
        (run/'launch.json').write_text(json.dumps({'source_sha256':'fixture'}))
        calls=[]
        def execute(command,log,env,timeout,cwd):
            log.write_text('offline fixture only\n')
            if '--model' not in command:return 0
            model=command[command.index('--model')+1];calls.append(model)
            output=Path(command[command.index('--output')+1]);output.mkdir(exist_ok=True)
            if fail(model,calls.count(model)):return 1
            (output/'summary.json').write_text('{}');return 0
        with patch.object(worker,'BASE',base),patch.object(worker.shutil,'disk_usage',return_value=types.SimpleNamespace(free=200*1024**3)),patch.dict(sys.modules,{'parent_exact_remote_v001':types.SimpleNamespace(execute=execute)}):
            worker.worker(run)
        return run,calls,json.loads((run/'status.json').read_text())

    def test_full_queue_and_verified_archives(self):
        with tempfile.TemporaryDirectory() as d:
            run,calls,state=self.run_queue(Path(d),lambda *_:False)
            self.assertEqual(calls,list(worker.MODELS));self.assertEqual(state['status'],'completed')
            self.assertEqual(state['test_evaluations_completed'],9);self.assertFalse(state['release_attempted'])
            for name in worker.MODELS:
                ready=json.loads((run/(name+'.tar.ready.json')).read_text())
                self.assertEqual(hashlib.sha256(Path(ready['path']).read_bytes()).hexdigest(),ready['sha256'])

    def test_retry_then_continue(self):
        with tempfile.TemporaryDirectory() as d:
            run,calls,state=self.run_queue(Path(d),lambda name,n:name==worker.MODELS[0] and n==1)
            self.assertEqual(calls,[worker.MODELS[0],*worker.MODELS]);self.assertEqual(state['status'],'completed')
            self.assertTrue((run/'artifacts'/f'{worker.MODELS[0]}-attempt-0.log').exists())

    def test_persistent_failure_retains_and_stops(self):
        with tempfile.TemporaryDirectory() as d:
            run,calls,state=self.run_queue(Path(d),lambda *_:True)
            self.assertEqual(calls,[worker.MODELS[0]]*2);self.assertEqual(state['status'],'failed')
            self.assertEqual(state['test_evaluations_completed'],0);self.assertFalse(state['release_attempted'])
            self.assertTrue((run/'archive-ready.json').exists())


if __name__=='__main__':unittest.main(verbosity=2)
