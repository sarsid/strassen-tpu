"""Diagnose one fresh v6e request and retain/adopt any resulting allocation.

Run only after suspending the study supervisor and reconciling its in-flight
request. Never print credentials, response bodies, or arbitrary headers.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import uuid

import colab_control_v003 as control


def response_summary(response):
    body = response.content
    lower = body.lower()
    phrases = (b'upstream request timeout', b'backend error', b'temporary error',
               b'bad gateway', b'quota', b'capacity', b'compute units',
               b'not available', b'502', b'please try again')
    return dict(http_status=response.status_code,
                content_type=response.headers.get('Content-Type', '').split(';')[0],
                body_bytes=len(body), body_sha256=hashlib.sha256(body).hexdigest(),
                recognized_phrases=[p.decode() for p in phrases if p in lower])


def request_once(client, old_id, new_id, emit):
    from colab_cli.client import Accelerator, Assignment, Variant
    existing = client.list_assignments()
    emit('preflight_assignments', count=len(existing))
    if existing:
        raise RuntimeError('Existing assignment requires ownership reconciliation')
    previous = client._get_assignment(old_id, Variant.TPU, Accelerator.V6E1)
    if isinstance(previous, Assignment):
        emit('old_identity_recovered')
        return previous
    control.remember_secret(previous.token)
    # A late result must be reconciled before changing the request identity.
    if client.list_assignments():
        raise RuntimeError('Assignment appeared during reconciliation')
    fresh = client._get_assignment(new_id, Variant.TPU, Accelerator.V6E1)
    if isinstance(fresh, Assignment):
        emit('fresh_identity_recovered')
        return fresh
    control.remember_secret(fresh.token)
    emit('fresh_identity_post', request_notebook_uuid=str(new_id))
    return client._post_assignment(new_id, fresh.token, Variant.TPU, Accelerator.V6E1)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--session', required=True, type=control.session_name)
    p.add_argument('--events', required=True, type=Path)
    p.add_argument('--config', type=Path, default=control.DEFAULT_CONFIG)
    p.add_argument('--token-file', type=Path, default=control.DEFAULT_TOKEN)
    a = p.parse_args()
    from colab_cli.client import Accelerator, Assignment, Variant
    from colab_cli.state import SessionState
    old_id = uuid.uuid5(uuid.NAMESPACE_URL, 'strassen-llm-provisioning/' + a.session)
    new_id = uuid.uuid5(uuid.NAMESPACE_URL, 'strassen-llm-provisioning-fresh-v002/' + a.session)
    def emit(kind, **fields):
        row = control.safe_value(dict(utc=datetime.now(timezone.utc).isoformat(), kind=kind, **fields))
        with a.events.open('a') as f:
            f.write(json.dumps(row) + '\n')
        control.emit(row)
    emit('diagnostic_identity', old_notebook_uuid=str(old_id), new_notebook_uuid=str(new_id),
         session=a.session, retain_on_success=True, benchmark_started=False)
    with control.api(a.token_file) as client:
        store = control.store_at(a.config)
        if store.get(a.session) is not None:
            raise RuntimeError('Session already saved; reconcile instead of allocating')
        original = client.session.request
        def observed(method, url, *args, **kwargs):
            assignment = url.split('?', 1)[0].endswith('/assign')
            if assignment:
                kwargs['timeout'] = (20, 600)
            started = time.monotonic()
            emit('http_request', method=method, operation='assign' if assignment else 'list')
            response = original(method, url, *args, **kwargs)
            data = response_summary(response) if response.status_code >= 400 else dict(http_status=response.status_code)
            emit('http_response', method=method, operation='assign' if assignment else 'list',
                 elapsed_seconds=round(time.monotonic() - started, 3), **data)
            return response
        client.session.request = observed
        assigned = None
        try:
            assigned = request_once(client, old_id, new_id, emit)
        except Exception as error:
            emit('allocation_error', **control.safe_error(error))
            # Reconcile both known identities after an ambiguous response; do
            # not send a second POST or destroy a possibly successful runtime.
            for identity in (new_id, old_id):
                try:
                    value = client._get_assignment(identity, Variant.TPU, Accelerator.V6E1)
                    if isinstance(value, Assignment):
                        if assigned is not None and assigned.endpoint != value.endpoint:
                            raise RuntimeError('Multiple assignments require manual reconciliation')
                        assigned = value
                    else:
                        control.remember_secret(value.token)
                except Exception as recovery_error:
                    emit('reconciliation_error', **control.safe_error(recovery_error))
        if assigned is None:
            emit('no_allocation', assignments_count=len(client.list_assignments()))
            return 1
        control.remember_secret(assigned.runtime_proxy_info.token)
        saved = SessionState(name=a.session, token=assigned.runtime_proxy_info.token,
                             url=assigned.runtime_proxy_info.url, endpoint=assigned.endpoint,
                             variant='TPU', accelerator='V6E1')
        store.add(saved)
        heartbeat = control.launch_heartbeat(a, saved, store)
        emit('allocation', created=True, session=a.session, endpoint=saved.endpoint,
             accelerator='V6E1', heartbeat_pid=heartbeat, retained=True)
        return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        control.emit(dict(kind='diagnostic_error', **control.safe_error(error)))
        raise SystemExit(1)
