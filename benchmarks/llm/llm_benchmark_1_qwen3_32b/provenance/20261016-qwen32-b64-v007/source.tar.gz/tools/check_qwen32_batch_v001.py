"""Offline checks for four-arm scoring, timing isolation and launch contracts."""
import ast
import hashlib
import json
from pathlib import Path
import types
import numpy as np
import jax
import jax.numpy as jnp
import qwen32_batch_stage_v001 as study


def main():
    root=Path(__file__).resolve().parents[1]
    plan=json.loads((root/'configs/qwen32_parent_batch_v001.json').read_text())
    assert tuple(plan['arms'])==study.ARMS and sorted(plan['batches'])==[1,4,8,16,32,64]
    assert plan['sequence']==1024 and plan['strassen_depth']==1 and not plan['other_models_queued']
    study.verify_parent()
    # A fake executable makes repeated-input versus recurrent-layer timing
    # distinguishable: every timing repeat must see its original input.
    calls=[]
    study.jax=types.SimpleNamespace(block_until_ready=lambda x:x)
    def function(arm):
        def fn(x): calls.append((arm,x)); return x+1
        return fn
    exes={arm:function(arm) for arm in study.ARMS}
    inputs={arm:(10+i,) for i,arm in enumerate(study.ARMS)}
    samples,outputs=study.round_robin(exes,inputs,2,5,offset=1)
    assert all(len(v)==5 for v in samples.values())
    assert len(calls)==28 and all(x==inputs[arm][0] for arm,x in calls)
    assert all(outputs[arm]==inputs[arm][0]+1 for arm in study.ARMS)
    assert [a for a,_ in calls[8:12]]==list(study.ARMS[1:]+study.ARMS[:1])
    # Independent NumPy oracle for masked loss, KL, agreement and logit errors.
    study.jax=jax; study.jnp=jnp; study.np=np
    study.sp=types.SimpleNamespace(native_matmul=lambda a,w:jnp.matmul(a,w))
    rng=np.random.default_rng(27)
    rows=[rng.normal(size=(4,3)).astype(np.float32) for _ in range(4)]
    rows[1]=rows[0].copy()
    weights=rng.normal(size=(3,7)).astype(np.float32); target=np.array([1,4,2,0],np.int32); mask=np.array([1,1,1,0],np.int32)
    actual,sq,mx,count,finite=jax.device_get(jax.jit(study.metric_chunk)(tuple(jnp.asarray(x) for x in rows),jnp.asarray(weights),jnp.asarray(target),jnp.asarray(mask)))
    logits=[x@weights for x in rows]
    def log_softmax(x):
        y=x.astype(np.float64)-x.max(axis=-1,keepdims=True); return y-np.log(np.exp(y).sum(axis=-1,keepdims=True))
    lp=[log_softmax(x) for x in logits]
    for i in range(4):
        diff=logits[i]-logits[0]
        expected=[-np.sum(lp[i][np.arange(4),target]*mask),np.sum((np.exp(lp[0])*(lp[0]-lp[i])).sum(axis=1)*mask),np.sum((logits[i].argmax(axis=1)==logits[0].argmax(axis=1))*mask),np.sum(diff*diff*mask[:,None]),np.max(np.abs(diff)*mask[:,None])]
        np.testing.assert_allclose(actual[i],expected,rtol=1e-5,atol=1e-5)
    assert finite and int(count)==3 and actual[1][1]==0 and actual[1][2]==3
    np.testing.assert_allclose(sq,np.sum(logits[0]**2*mask[:,None]),rtol=1e-6)
    np.testing.assert_allclose(mx,np.max(np.abs(logits[0])*mask[:,None]),rtol=1e-6)
    bad=list(rows); bad[3]=bad[3].copy(); bad[3][0,0]=np.nan
    assert not bool(study.metric_chunk(tuple(jnp.asarray(x) for x in bad),jnp.asarray(weights),jnp.asarray(target),jnp.asarray(mask))[-1])
    for batch in plan['batches']:
        profile=study.default_profile(batch,1024)
        for tile in [profile['product_tile'],profile['cubic_tile'],profile['qk_tile'],*profile['strassen_sites'].values()]:
            assert batch*1024%tile[0]==0
    sources=['tools/qwen32_batch_stage_v001.py','tools/run_qwen32_batch_v001.py','runtime/qwen32_batch_remote_v001.py','runtime/poll_qwen32_batch_v001.py']
    for name in sources: ast.parse((root/name).read_text())
    remote=ast.parse((root/'runtime/qwen32_batch_remote_v001.py').read_text())
    assert not any(isinstance(n,ast.ImportFrom) and n.module=='parent_exact_remote_v001' for n in remote.body)
    print(json.dumps(dict(status='passed',checks=['parent_hashes','six_workloads_four_arms','timing_repeat_input_isolation','rotating_order','four_arm_masked_metrics_numpy_oracle','nonfinite_logits','batch_tile_alignment','standalone_remote_bootstrap'],source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources})))


if __name__=='__main__': main()
