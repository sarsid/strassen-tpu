"""Algorithm-only BF16 projection seam; no fused model epilogues.

This is an admission component, not a complete model/evaluation runner.
The caller must freeze the explicit tile and projection routing before scoring.
"""
from pathlib import Path
import sys
import jax
import jax.numpy as jnp

PARENT=Path(__file__).resolve().parents[1]/'third_party/strassen_tpu_public_95be1fb_v001'


def rounded(value):
    # A cast alone can disappear when XLA fuses a BF16 producer into an FP32
    # consumer. Preserve the actual BF16 rounding boundary in both arms.
    return jax.lax.reduce_precision(value.astype(jnp.float32),exponent_bits=8,mantissa_bits=7).astype(jnp.bfloat16)


def make_projection(arm, tile, *, interpret=False):
    if arm not in ('native','strassen'):raise ValueError('Expected Native or Strassen')
    bm,bn,bk=map(int,tile)
    if bm<=0 or bm%16 or bn<=0 or bn%256 or bk<=0 or bk%256:raise ValueError('Invalid parent S1 tile')
    if arm=='strassen':
        sys.path.insert(0,str(PARENT))
        import strassen_pallas as sp
    def projection(lhs,weight):
        if lhs.dtype!=jnp.bfloat16 or weight.dtype!=jnp.bfloat16:raise ValueError('Require identical BF16 operands')
        if weight.ndim!=2 or lhs.shape[-1]!=weight.shape[0]:raise ValueError('Invalid linear projection')
        shape=lhs.shape;flat=lhs.reshape(-1,shape[-1]);m,k=flat.shape;n=weight.shape[1]
        if k%bk or n%bn:raise ValueError('Unsupported shape: no silent native fallback')
        padding=(-m)%bm
        flat=rounded(jnp.pad(flat,((0,padding),(0,0))));weight=rounded(weight)
        if arm=='native':
            result=rounded(jnp.matmul(flat,weight,precision=jax.lax.Precision.DEFAULT,preferred_element_type=jnp.float32))
        else:
            result=sp.strassen_matmul(flat,weight,bm=bm,bn=bn,bk=bk,
                dot_precision=jax.lax.Precision.DEFAULT,interleave_products=True,
                formula_variant='classical',epilogue=None,output_dtype=jnp.bfloat16,
                allow_input_fusion=(False,False),interpret=interpret,
                vmem_limit_bytes=120*1024**2)
            result=rounded(result)
        return result[:m].reshape(*shape[:-1],n)
    projection.contract=dict(arm=arm,tile=[bm,bn,bk],depth=1 if arm=='strassen' else 0,
        input_dtype='bfloat16',output_dtype='bfloat16',accumulator='float32',precision='DEFAULT',
        epilogue=None,input_fusion=False,common_m_padding=True,implicit_fallback=False)
    return projection


def qwen_rms(x,scale,eps):
    value=x.astype(jnp.float32)
    normalized=rounded(value*jax.lax.rsqrt(jnp.mean(value*value,axis=-1,keepdims=True)+eps))
    return rounded(normalized.astype(jnp.float32)*scale.astype(jnp.float32))


def qwen_mlp(x,weights,project):
    # Match separate reference Linear -> SiLU -> BF16 product boundaries.
    gate=project(x,weights['gate']);up=project(x,weights['up'])
    activated=rounded(jax.nn.silu(gate.astype(jnp.float32)))
    return project(rounded(activated.astype(jnp.float32)*up.astype(jnp.float32)),weights['down'])


def gemma_mlp(x,weights,project):
    gate=project(x,weights['gate']);up=project(x,weights['up'])
    activated=rounded(jax.nn.gelu(gate.astype(jnp.float32),approximate=True))
    return project(rounded(activated.astype(jnp.float32)*up.astype(jnp.float32)),weights['down'])
