"""Run one CPU-only semantic control on the retained diagnostic runtime."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--script',type=Path,required=True)
    parser.add_argument('--sha256',required=True);args=parser.parse_args()
    base=Path('/content/Strassen_MM_Focus');parent=base/'runs/20261016-gemma4-numerics-v001'
    if not args.script.resolve().is_relative_to(base) or hashlib.sha256(args.script.read_bytes()).hexdigest()!=args.sha256:raise ValueError('Source integrity mismatch')
    state=json.loads((parent/'status.json').read_text())
    if state.get('status')!='completed' or state.get('qualification')!='diagnostic_completed':raise RuntimeError('Original diagnostic must finish first')
    run=base/'runs/20261016-gemma4-fp32-semantics-v001';run.mkdir(exist_ok=False)
    private=base/'.runtime_private'/parent.name
    env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','HF_TOKEN','HUGGING_FACE_HUB_TOKEN','LIBTPU_INIT_ARGS','XLA_FLAGS')}
    env.update(JAX_PLATFORMS='cpu',PYTHONUNBUFFERED='1',PYTHONNOUSERSITE='1',HF_HOME=str(private/'huggingface'),HF_HUB_DISABLE_IMPLICIT_TOKEN='1',OMP_NUM_THREADS='1')
    command=[str(private/'parent/bin/python'),str(args.script),'--reference-source',str(parent/'source'),
        '--cache',str(private/'checkpoint'),'--captures',str(parent/'artifacts/oracle-a0'),'--output',str(run/'artifacts')]
    record=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_sha256=args.sha256,scope='CPU FP32 formula comparison; no performance measurement',release_attempted=False)
    with (run/'execution.log').open('x') as log:
        child=subprocess.Popen(command,env=env,cwd=parent/'source',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        record.update(pid=child.pid,status='running');(run/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record),flush=True)
        try:
            code=child.wait(timeout=360);record.update(status='completed' if code==0 else 'failed',exit_code=code)
        except subprocess.TimeoutExpired:
            record.update(status='still_running',error='Wait timed out; inspect this PID before any retry')
    record['observed_utc']=datetime.now(timezone.utc).isoformat()
    (run/'completion.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)


if __name__=='__main__':main()
